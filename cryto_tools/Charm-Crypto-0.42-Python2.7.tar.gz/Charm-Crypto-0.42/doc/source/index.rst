.. Charm-Crypto documentation master file, created by
   sphinx-quickstart on Wed Jul 20 14:42:25 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Charm-Crypto's documentation!
========================================
.. sectionauthor:: My Name

Contents:

.. toctree::
   :maxdepth: 1

   install_source 
   cryptographers
   developers
   mobile

Developer Resources

.. toctree::
   :maxdepth: 1

   schemes
   toolbox
   todo

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

