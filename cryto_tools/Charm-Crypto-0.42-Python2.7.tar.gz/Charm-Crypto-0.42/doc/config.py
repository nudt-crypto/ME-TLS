

skip_list  = ['pk_fre_ccv11']
charm_path = "../charm"
toolbox_path = charm_path + "/toolbox"
zkp_path = charm_path + "/zkp_compiler"
scheme_path = "charm/schemes" 
abenc_path = scheme_path + "/abenc"
dabenc_path = scheme_path + "/dabenc"
pkenc_path  = scheme_path + "/pkenc"
pksig_path  = scheme_path + "/pksig"
ibenc_path  = scheme_path + "/ibenc"
hibenc_path = scheme_path + "/hibenc"
commit_path = scheme_path + "/commit"
grp_path    = scheme_path + "/grpsig"
